# fireworks
HTML5+Canvas漂亮的3D烟花动画生日特效，节日特效，烟花

![image](http://upload-images.jianshu.io/upload_images/6411787-aaf971906d6a5922?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240) 
![image](http://upload-images.jianshu.io/upload_images/6411787-fb4a6506ca1bf129?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)  
![image](http://upload-images.jianshu.io/upload_images/6411787-fc45fd483ca986dc?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)  
![image](http://upload-images.jianshu.io/upload_images/6411787-e8fda7078860c7d1?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)  
https://github.com/louislivi/fireworks
